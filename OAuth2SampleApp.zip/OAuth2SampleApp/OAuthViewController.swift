//
//  OAuthViewController.swift
//  iOSSwiftExample
//
//  Created by Abel Osorio on 3/13/19.
//  Copyright © 2019 Box Inc. All rights reserved.
//

import BoxSDK
import UIKit

class OAuthViewController: UITableViewController {

    var sdk: BoxSDK!
    var client: BoxClient!
    var folderItems: [FolderItem] = []
    private lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd,yyyy at HH:mm a"
        return formatter
    }()

    // MARK: - View life cycle

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "OAuth 2.0 Example"
        sdk = BoxSDK(clientId: Constants.clientId, clientSecret: Constants.clientSecret)
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Login", style: .plain, target: self, action: #selector(loginPressed))
        tableView.tableFooterView = UIView()
    }

    // MARK: - Actions

    @objc func loginPressed() {
        if navigationItem.rightBarButtonItem?.title == "Login" {
            getOAuthClient()
        }
        else {
            getRootFolderItems()
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in _: UITableView) -> Int {
        return 1
    }

    override func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int {
        return folderItems.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FileCell", for: indexPath)
        let item = folderItems[indexPath.row]
        if case let .file(file) = item.itemValue {
            cell.textLabel?.text = file.name
            cell.detailTextLabel?.text = String(format: "Date Modified %@", dateFormatter.string(from: file.modifiedAt ?? Date()))
            cell.accessoryType = .none
        }
        else if case let .folder(folder) = item.itemValue {
            cell.textLabel?.text = folder.name
            cell.detailTextLabel?.text = ""
            cell.accessoryType = .disclosureIndicator
            cell.imageView?.image = UIImage(named: "folderIcon")
        }

        return cell
    }
}

// MARK: - Helpers

extension OAuthViewController {
    func getOAuthClient() {
        sdk.getOAuth2Client { [weak self] result in
            switch result {
            case let .success(client):
                self?.client = client
                self?.getRootFolderItems()
            case let .failure(error):
                print("\(error)")
            }
        }
    }

    func getRootFolderItems() {
        let iterator: PaginationIterator<FolderItem> = client.folders.getFolderItems(
            folderId: "0",
            usemarker: true,
            fields: ["modified_at", "name"]
        )

        iterator.nextItems { [weak self] result in
            switch result {
            case let .success(items):
                self?.folderItems = items
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                    self?.navigationItem.rightBarButtonItem?.title = "Refresh"
                }
            case let .failure(error):
                print("error: \(error)")
            }
        }
    }
}
